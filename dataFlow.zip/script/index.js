/* 
    !!!: Day la file JS tong 

    Trong truong hop muon them script thi tao them file JS moi.
*/